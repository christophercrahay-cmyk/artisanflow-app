// services/transcriptionService.js
import { OPENAI_CONFIG } from '../config/openai';

/**
 * Transcrit un audio avec Whisper API
 * @param {string} audioUri - Chemin vers le fichier audio M4A
 * @returns {Promise<string>} Texte transcrit
 */
export const transcribeAudio = async (audioUri) => {
  try {
    console.log('[Transcription] Début:', audioUri);
    
    const formData = new FormData();
    formData.append('file', {
      uri: audioUri,
      type: 'audio/m4a',
      name: 'audio.m4a'
    });
    formData.append('model', OPENAI_CONFIG.models.whisper);
    formData.append('language', 'fr');
    formData.append('response_format', 'json');
    
    const response = await fetch(
      `${OPENAI_CONFIG.apiUrl}/audio/transcriptions`,
      {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${OPENAI_CONFIG.apiKey}`,
        },
        body: formData
      }
    );
    
    if (!response.ok) {
      const error = await response.json();
      throw new Error(`Whisper API error: ${error.error?.message || response.status}`);
    }
    
    const data = await response.json();
    console.log('[Transcription] Succès:', data.text);
    
    return data.text;
    
  } catch (error) {
    console.error('[Transcription] Erreur:', error);
    throw error;
  }
};

/**
 * Retranscrit un audio existant (si première tentative a échoué)
 */
export const retranscribeNote = async (noteId, audioUri) => {
  try {
    const text = await transcribeAudio(audioUri);
    // Mettre à jour la note dans la DB
    // await updateNoteTranscription(noteId, text);
    return text;
  } catch (error) {
    console.error('[Retranscription] Erreur:', error);
    throw error;
  }
};
