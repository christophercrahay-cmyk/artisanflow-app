// Configuration Sentry
// ⚠️ NE PAS COMMITER CE FICHIER AVEC VOTRE VRAI DSN
// Copier depuis config/sentry.example.js et remplir vos valeurs

export const SENTRY_CONFIG = {
  dsn: '', // Ajouter votre DSN Sentry ici
  environment: __DEV__ ? 'development' : 'production',
  enableInExpoDevelopment: false, // Désactiver Sentry en dev Expo
  debug: __DEV__,
  
  // Options avancées
  tracesSampleRate: 1.0, // 100% des transactions tracées (ajuster en prod)
  enableAutoSessionTracking: true,
  sessionTrackingIntervalMillis: 30000,
};

