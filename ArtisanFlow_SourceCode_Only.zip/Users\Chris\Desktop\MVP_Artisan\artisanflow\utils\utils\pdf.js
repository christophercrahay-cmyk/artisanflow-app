import * as Print from 'expo-print';
import * as FileSystem from 'expo-file-system';
import { supabase } from '../../supabaseClient';
import logger from '../logger';

/**
 * Génère un numéro de devis unique : DE-YYYY-#### (#### = incrément local simple)
 * Tu pourras plus tard remplacer par un compteur DB.
 */
function generateDevisNumber() {
  const year = new Date().getFullYear();
  const rand = Math.floor(1000 + Math.random() * 9000); // 4 chiffres
  return `DE-${year}-${rand}`;
}

/**
 * Template HTML/CSS A4 très simple et propre (MVP)
 * - logoUrl optionnel (en <img>)
 * - company : { name, siret, address, phone, email }
 * - client : { name, address, phone, email }
 * - project : { title, address }
 * - lignes : [{ designation, quantity, unit, unitPriceHT }]
 * - tva : nombre (ex: 20)
 * - template: 'minimal' | 'classique' | 'bandeBleue'
 */
function buildDevisHTML({ number, dateISO, company, client, project, lignes, tva, logoUrl, template = 'classique' }) {
  const companyBlock = `
    <div class="company">
      ${logoUrl ? `<img class="logo" src="${logoUrl}" />` : ''}
      <div>
        <div class="c-name">${company?.name || ''}</div>
        ${company?.siret ? `<div>SIRET : ${company.siret}</div>` : ''}
        ${company?.address ? `<div>${company.address}</div>` : ''}
        ${company?.phone ? `<div>${company.phone}</div>` : ''}
        ${company?.email ? `<div>${company.email}</div>` : ''}
      </div>
    </div>
  `;

  const clientBlock = `
    <div class="block">
      <div class="b-title">Destinataire</div>
      <div><strong>${client?.name || ''}</strong></div>
      ${client?.address ? `<div>${client.address}</div>` : ''}
      ${client?.phone ? `<div>${client.phone}</div>` : ''}
      ${client?.email ? `<div>${client.email}</div>` : ''}
    </div>
  `;

  const projectBlock = `
    <div class="block">
      <div class="b-title">Chantier</div>
      <div><strong>${project?.title || ''}</strong></div>
      ${project?.address ? `<div>${project.address}</div>` : ''}
    </div>
  `;

  // Totaux
  const rows = (lignes || []).map((l) => {
    const q = Number(l.quantity || 0);
    const pu = Number(l.unitPriceHT || 0);
    const total = q * pu;
    return `
      <tr>
        <td>${l.designation || ''}</td>
        <td class="num">${q}</td>
        <td>${l.unit || ''}</td>
        <td class="num">${pu.toFixed(2)} €</td>
        <td class="num">${total.toFixed(2)} €</td>
      </tr>
    `;
  }).join('');

  const totalHT = (lignes || []).reduce((acc, l) => acc + Number(l.quantity || 0) * Number(l.unitPriceHT || 0), 0);
  const tvaRate = Number(tva || 0) / 100;
  const totalTVA = totalHT * tvaRate;
  const totalTTC = totalHT + totalTVA;

  // Styles selon template
  let templateStyles = '';
  let headerClass = 'header';
  let docTitleClass = 'doc-title';

  if (template === 'minimal') {
    templateStyles = `
  body { font-family: Georgia, serif; color: #111; }
  .header { border-bottom: 2px solid #000; padding-bottom: 16px; }
  .doc-title { font-size: 24px; font-weight: 900; letter-spacing: 2px; }
  .doc-line { color: #000; font-size: 13px; }
  .b-title { font-weight: 800; text-transform: uppercase; letter-spacing: 1px; }
  table th { background: #fafafa; border-bottom: 2px solid #000; }
  .totals-row:last-child { border-top: 2px solid #000; background: #fff; }
    `;
  } else if (template === 'bandeBleue') {
    templateStyles = `
  body { font-family: Arial, sans-serif; color: #111; }
  .header { background: linear-gradient(135deg, #1D4ED8 0%, #3B82F6 100%); color: white; padding: 24px; border-radius: 12px; margin-bottom: 24px; }
  .company { color: white; }
  .doc-meta { text-align: right; color: white; }
  .doc-title { font-size: 28px; font-weight: 800; margin: 0; color: white; }
  .doc-line { color: rgba(255,255,255,0.9); font-weight: 500; }
  .block { border: 2px solid #1D4ED8; border-radius: 8px; }
  .b-title { color: #1D4ED8; font-weight: 800; }
  table th { background: #1D4ED8; color: white; font-weight: 700; }
  .totals-row:last-child { background: #1D4ED8; color: white; font-weight: 800; }
    `;
  } else { // classique
    templateStyles = `
  body { font-family: Arial, Helvetica, sans-serif; color: #111; }
  .header { display:flex; justify-content: space-between; align-items:flex-start; margin-bottom: 18px; }
  .doc-title { font-size: 22px; font-weight: 800; margin: 0; }
  .doc-line { color:#444; }
    `;
  }

  return `
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Devis ${number}</title>
<style>
  @page { size: A4; margin: 24mm; }
  ${templateStyles}
  
  .header { display:flex; justify-content: space-between; align-items:flex-start; margin-bottom: 18px; }
  .company { display:flex; gap:14px; align-items:flex-start; }
  .logo { width: 80px; height: 80px; object-fit: contain; border: 1px solid #eee; }
  .c-name { font-weight: 700; font-size: 16px; margin-bottom: 4px; }

  .doc-meta { text-align: right; }

  .grid { display:flex; gap:16px; margin-top: 12px; }
  .block { flex:1; border:1px solid #eee; padding:10px; border-radius:8px; }
  .b-title { font-weight:700; margin-bottom: 6px; }

  table { width:100%; border-collapse: collapse; margin-top: 16px; }
  th, td { border: 1px solid #eaeaea; padding: 8px; font-size: 13px; }
  th { background:#f6f7fb; text-align:left; }
  .num { text-align: right; white-space: nowrap; }

  .totals { width: 320px; margin-left:auto; margin-top: 12px; border:1px solid #eee; border-radius: 8px; overflow:hidden; }
  .totals-row { display:flex; justify-content: space-between; padding: 8px 10px; border-bottom: 1px solid #eee; }
  .totals-row:last-child { border-bottom: none; background:#f6f7fb; font-weight:700; }

  .legal { margin-top: 18px; font-size: 12px; color:#555; }
  .sign { margin-top: 28px; border:1px dashed #bbb; height: 80px; display:flex; align-items:center; justify-content:center; color:#777; border-radius: 8px; }
</style>
</head>
<body>
  <div class="header">
    ${companyBlock}
    <div class="doc-meta">
      <h1 class="doc-title">DEVIS</h1>
      <div class="doc-line">Numéro : <strong>${number}</strong></div>
      <div class="doc-line">Date : ${dateISO}</div>
    </div>
  </div>

  <div class="grid">
    ${clientBlock}
    ${projectBlock}
  </div>

  <table>
    <thead>
      <tr>
        <th style="width:52%;">Désignation</th>
        <th style="width:8%;">Qté</th>
        <th style="width:10%;">Unité</th>
        <th style="width:15%;">PU HT</th>
        <th style="width:15%;">Total HT</th>
      </tr>
    </thead>
    <tbody>
      ${rows || ''}
      ${rows ? '' : `<tr><td colspan="5" style="text-align:center;color:#777;">(Aucune ligne)</td></tr>`}
    </tbody>
  </table>

  <div class="totals">
    <div class="totals-row"><div>Total HT</div><div>${totalHT.toFixed(2)} €</div></div>
    <div class="totals-row"><div>TVA ${Number(tva||0).toFixed(0)}%</div><div>${totalTVA.toFixed(2)} €</div></div>
    <div class="totals-row"><div>Total TTC</div><div>${totalTTC.toFixed(2)} €</div></div>
  </div>

  <div class="legal">
    <div>Validité du devis : 30 jours à compter de la date d’émission.</div>
    <div>Acompte : 30% à la commande – Solde à la fin des travaux.</div>
  </div>

  <div class="sign">Signature du client</div>
</body>
</html>
`;
}

/**
 * Génère un PDF local puis l'upload dans Supabase Storage (bucket "docs").
 * Retourne { pdfUrl, number }.
 */
export async function generateDevisPDF({
  company,
  client,
  project,
  lignes = [],
  tva = 20,
  logoUrl = null,
  template = 'classique',
}) {
  try {
    logger.info('PDF', 'generateDevisPDF appelé', {
      hasCompany: !!company,
      hasClient: !!client,
      hasProject: !!project,
      lignesCount: lignes?.length || 0,
    });
    
    // Validation des paramètres
    if (!company) {
      throw new Error('Paramètre company manquant');
    }
    if (!client) {
      throw new Error('Paramètre client manquant');
    }
    if (!project) {
      throw new Error('Paramètre project manquant');
    }
    if (!lignes || lignes.length === 0) {
      throw new Error('Aucune ligne de devis fournie');
    }
    
    const number = generateDevisNumber();
    const dateISO = new Date().toLocaleDateString('fr-FR');

    logger.info('PDF', `Génération devis ${number}`, { projectId: project?.id, template });

    // 1) HTML
    logger.info('PDF', 'Construction HTML...');
    const html = buildDevisHTML({
      number,
      dateISO,
      company,
      client,
      project,
      lignes,
      tva,
      logoUrl,
      template,
    });
    
    if (!html) {
      throw new Error('HTML généré est vide');
    }
    
    logger.info('PDF', 'HTML construit', { htmlLength: html.length });

    // 2) Générer PDF local
    logger.info('PDF', 'Appel Print.printToFileAsync...');
    
    let printResult;
    try {
      printResult = await Print.printToFileAsync({ html });
    } catch (printError) {
      logger.error('PDF', 'Erreur Print.printToFileAsync', printError);
      throw new Error(`Impossible de créer le PDF: ${printError.message}`);
    }
    
    if (!printResult || !printResult.uri) {
      throw new Error('Print.printToFileAsync n\'a pas retourné d\'URI');
    }
    
    const { uri } = printResult;
    logger.success('PDF', `PDF local créé: ${uri}`);

    // 3) Upload dans Supabase Storage
    const path = `devis/${project?.id || 'unknown'}/${number}.pdf`;

  logger.info('PDF', `Début upload: ${path}`);

  try {
    // Lire le fichier PDF comme bytes (comme pour les photos/audio)
    const resp = await fetch(uri);
    const arrayBuffer = await resp.arrayBuffer();
    const bytes = new Uint8Array(arrayBuffer);

    logger.info('PDF', `Fichier lu - Taille: ${bytes.length} bytes`);

    const { data: uploadData, error: upErr } = await supabase.storage
      .from('docs')
      .upload(path, bytes, {
        contentType: 'application/pdf',
        upsert: true,
      });

    if (upErr) {
      logger.error('PDF', 'Erreur upload', upErr);
      throw new Error(`Upload échoué : ${upErr.message || 'inconnu'}. 
Vérifie que le bucket "docs" existe et est public dans Supabase.`);
    }

    logger.success('PDF', `Upload réussi: ${path}`);

    // 4) URL publique
    const { data } = supabase.storage.from('docs').getPublicUrl(path);
    const pdfUrl = data?.publicUrl;

    logger.success('PDF', `URL publique: ${pdfUrl}`, { numero: number });

    // 5) Retour
    return { pdfUrl, number, localUri: uri };
  } catch (uploadError) {
    logger.error('PDF', 'Exception upload', uploadError);
    // On retourne quand même l'URI local pour le partage
    return { pdfUrl: null, number, localUri: uri };
  }
  } catch (error) {
    logger.error('PDF', 'Exception generateDevisPDF', error);
    throw error; // Propager l'erreur pour que handleGeneratePDF l'attrape
  }
}
