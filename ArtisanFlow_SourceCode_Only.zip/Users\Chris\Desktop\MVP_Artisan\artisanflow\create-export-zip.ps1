# Script pour créer une archive ZIP complète d'ArtisanFlow
# Exclut : node_modules, .expo, .git, ios/build, android/build, *.log

$sourcePath = Get-Location
$zipFileName = "ArtisanFlow_Complete_Export.zip"
$zipPath = Join-Path $sourcePath $zipFileName

# Supprimer l'ancien ZIP s'il existe
if (Test-Path $zipPath) {
    Remove-Item $zipPath -Force
    Write-Host "Ancien ZIP supprimé" -ForegroundColor Yellow
}

# Créer un dossier temporaire
$tempFolder = Join-Path $env:TEMP "ArtisanFlow_Export_Temp"
if (Test-Path $tempFolder) {
    Remove-Item $tempFolder -Recurse -Force
}
New-Item -ItemType Directory -Path $tempFolder | Out-Null

Write-Host "Copie des fichiers en cours..." -ForegroundColor Cyan

# Liste des exclusions
$excludePatterns = @(
    '*/node_modules/*',
    '*/.expo/*',
    '*/.git/*',
    '*/ios/build/*',
    '*/android/build/*',
    '*.log',
    '*/-ErrorAction/*',
    '*/-p/*',
    '*/`$null/*',
    '*/SilentlyContinue/*',
    '*/New/*',
    '*/expo/*',
    '*/artisanflow/*'
)

# Copier tous les fichiers sauf les exclusions
Get-ChildItem -Path $sourcePath -Recurse -Force | ForEach-Object {
    $relativePath = $_.FullName.Replace($sourcePath, "")
    
    # Vérifier si le fichier doit être exclu
    $shouldExclude = $false
    foreach ($pattern in $excludePatterns) {
        if ($relativePath -like $pattern) {
            $shouldExclude = $true
            break
        }
    }
    
    # Si c'est le fichier ZIP lui-même, l'exclure
    if ($_.FullName -eq $zipPath) {
        $shouldExclude = $true
    }
    
    if (-not $shouldExclude) {
        $destPath = Join-Path $tempFolder $relativePath
        
        if ($_.PSIsContainer) {
            # C'est un dossier
            if (-not (Test-Path $destPath)) {
                New-Item -ItemType Directory -Path $destPath -Force | Out-Null
            }
        } else {
            # C'est un fichier
            $destDir = Split-Path $destPath -Parent
            if (-not (Test-Path $destDir)) {
                New-Item -ItemType Directory -Path $destDir -Force | Out-Null
            }
            Copy-Item $_.FullName -Destination $destPath -Force
        }
    }
}

Write-Host "Création de l'archive ZIP..." -ForegroundColor Cyan

# Créer le ZIP
Compress-Archive -Path "$tempFolder\*" -DestinationPath $zipPath -Force

# Nettoyer le dossier temporaire
Remove-Item $tempFolder -Recurse -Force

# Afficher la taille du ZIP
$zipSize = (Get-Item $zipPath).Length / 1MB
Write-Host "`nArchive créée avec succès !" -ForegroundColor Green
Write-Host "Fichier : $zipFileName" -ForegroundColor Green
Write-Host "Taille : $([math]::Round($zipSize, 2)) MB" -ForegroundColor Green
Write-Host "Emplacement : $zipPath" -ForegroundColor Green

