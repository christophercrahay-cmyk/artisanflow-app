# create-clean-export.ps1
# Create a lightweight ZIP archive with ONLY source code, config and docs

$SourcePath = Get-Location
$DestinationZip = Join-Path $SourcePath "ArtisanFlow_SourceCode_Only.zip"

Write-Host "=== CREATION ARCHIVE ZIP LEGERE ===" -ForegroundColor Cyan
Write-Host "Source: $SourcePath"
Write-Host "Destination: $DestinationZip"
Write-Host ""

# List of folders and files to EXCLUDE
$ExcludeFolders = @(
    'node_modules',
    '.git',
    '.expo',
    'ios',
    'android',
    '.next',
    'dist',
    'build',
    '.cache',
    'coverage',
    'tmp',
    'temp',
    '.vscode',
    '.idea',
    'ArtisanFlow_Export_Temp'
)

$ExcludeExtensions = @(
    '*.log',
    '*.tmp',
    '*.cache',
    '*.mp4',
    '*.mov',
    '*.avi',
    '*.zip',
    '*.tar',
    '*.gz'
)

Write-Host "Exclusions:" -ForegroundColor Yellow
Write-Host "- Folders: $($ExcludeFolders -join ', ')"
Write-Host "- Extensions: $($ExcludeExtensions -join ', ')"
Write-Host ""

# Create temporary directory
$TempDir = Join-Path $SourcePath "ArtisanFlow_Export_Temp"
if (Test-Path $TempDir) {
    Remove-Item $TempDir -Recurse -Force
}
New-Item -ItemType Directory -Path $TempDir | Out-Null

Write-Host "Copying source code files..." -ForegroundColor Green

# Function to check if a path should be excluded
function Should-Exclude {
    param($Path, $RootPath)
    
    $RelativePath = $Path.FullName.Substring($RootPath.Length + 1)
    
    # Check excluded folders
    foreach ($ExcludeFolder in $ExcludeFolders) {
        if ($RelativePath -like "*\$ExcludeFolder\*" -or $RelativePath -eq $ExcludeFolder) {
            return $true
        }
    }
    
    # Check excluded extensions
    foreach ($ExcludeExt in $ExcludeExtensions) {
        if ($Path.Name -like $ExcludeExt) {
            return $true
        }
    }
    
    return $false
}

# Get all files and folders, excluding patterns
$AllItems = Get-ChildItem -Path $SourcePath -Recurse -ErrorAction SilentlyContinue

$ItemsToInclude = $AllItems | Where-Object {
    -not (Should-Exclude -Path $_ -RootPath $SourcePath)
}

Write-Host "Files to copy: $($ItemsToInclude.Count)"

# Copy files
$CopiedCount = 0
foreach ($Item in $ItemsToInclude) {
    $RelativePath = $Item.FullName.Substring($SourcePath.Length + 1)
    $DestinationPath = Join-Path $TempDir $RelativePath
    
    if ($Item.PSIsContainer) {
        # Create folder if it doesn't exist
        if (-not (Test-Path $DestinationPath)) {
            New-Item -ItemType Directory -Path $DestinationPath -Force | Out-Null
        }
    } else {
        # Create parent folder if necessary
        $ParentDir = Split-Path $DestinationPath -Parent
        if (-not (Test-Path $ParentDir)) {
            New-Item -ItemType Directory -Path $ParentDir -Force | Out-Null
        }
        
        # Copy file
        Copy-Item -Path $Item.FullName -Destination $DestinationPath -Force
        $CopiedCount++
        
        if ($CopiedCount % 100 -eq 0) {
            Write-Host "  Copied: $CopiedCount files..." -NoNewline -ForegroundColor Gray
            Write-Host "`r" -NoNewline
        }
    }
}

Write-Host ""
Write-Host "Total copied: $CopiedCount files" -ForegroundColor Green
Write-Host ""

# Remove old archive if it exists
if (Test-Path $DestinationZip) {
    Remove-Item $DestinationZip -Force
}

Write-Host "Creating ZIP archive..." -ForegroundColor Green
Compress-Archive -Path "$TempDir\*" -DestinationPath $DestinationZip -CompressionLevel Optimal -Force

# Clean up temporary folder
Remove-Item $TempDir -Recurse -Force

# Display result
$ZipSize = (Get-Item $DestinationZip).Length
$ZipSizeMB = [math]::Round($ZipSize / 1MB, 2)

Write-Host ""
Write-Host "=== RESULT ===" -ForegroundColor Cyan
Write-Host "SUCCESS! Archive created" -ForegroundColor Green
Write-Host "File: $DestinationZip"
Write-Host "Size: $ZipSizeMB MB"
Write-Host "Content: Source code, config, docs only" -ForegroundColor Yellow

