// config/openai.js
// NE PAS COMMITER CETTE CLÉ - AJOUTER .env AU .gitignore

export const OPENAI_CONFIG = {
  apiKey: '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', // À remplacer par votre clé API OpenAI
  apiUrl: 'https://api.openai.com/v1',
  models: {
    whisper: 'whisper-1',
    gpt: 'gpt-4o-mini' // Moins cher, rapide, précis
  }
};
