# analyze-size.ps1
# Analyse des fichiers et dossiers les plus lourds

Write-Host "=== FICHIERS LES PLUS LOURDS (> 1 MB) ===" -ForegroundColor Cyan
Get-ChildItem -Path . -Recurse -File -ErrorAction SilentlyContinue | 
    Where-Object { $_.Length -gt 1MB } | 
    Sort-Object Length -Descending | 
    Select-Object -First 20 | 
    ForEach-Object {
        $sizeMB = [math]::Round($_.Length/1MB, 2)
        $relativePath = $_.FullName.Replace((Get-Location).Path, ".")
        Write-Host "$sizeMB MB - $relativePath"
    }

Write-Host "`n=== TAILLE DES DOSSIERS PRINCIPAUX ===" -ForegroundColor Cyan
Get-ChildItem -Path . -Directory -ErrorAction SilentlyContinue | 
    Where-Object { $_.Name -notin @('node_modules', '.git', '.expo', 'ios', 'android') } |
    ForEach-Object {
        $size = (Get-ChildItem $_.FullName -Recurse -File -ErrorAction SilentlyContinue | 
                 Measure-Object -Property Length -Sum).Sum
        $sizeMB = [math]::Round($size/1MB, 2)
        [PSCustomObject]@{
            Dossier = $_.Name
            'Taille (MB)' = $sizeMB
        }
    } | 
    Sort-Object 'Taille (MB)' -Descending | 
    Format-Table -AutoSize

Write-Host "`n=== TAILLE DES GROS DOSSIERS EXCLUS ===" -ForegroundColor Yellow
$excludedDirs = @('node_modules', '.git', '.expo', 'ios', 'android')
foreach ($dir in $excludedDirs) {
    if (Test-Path $dir) {
        $size = (Get-ChildItem $dir -Recurse -File -ErrorAction SilentlyContinue | 
                 Measure-Object -Property Length -Sum).Sum
        $sizeMB = [math]::Round($size/1MB, 2)
        Write-Host "$dir : $sizeMB MB"
    }
}

