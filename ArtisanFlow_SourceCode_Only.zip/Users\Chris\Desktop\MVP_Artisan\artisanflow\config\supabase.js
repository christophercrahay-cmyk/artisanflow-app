// Configuration Supabase
// ⚠️ NE PAS COMMITER CE FICHIER AVEC VOS VRAIES CLÉS
// Les clés sont disponibles dans Supabase Dashboard → Settings → API

export const SUPABASE_CONFIG = {
  url: 'https://upihalivqstavxijlwaj.supabase.co',
  anonKey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InVwaWhhbGl2cXN0YXZ4aWpsd2FqIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjE3NjIxMzksImV4cCI6MjA3NzMzODEzOX0.LiTut-3fm7XPAALAi6KQkS1hcwXUctUTPwER9V7cAzs'
};

